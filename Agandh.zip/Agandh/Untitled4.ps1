﻿ for ($e=10;$e -ge 1; $e--)

 {


 for ($f=0;$f -lt $e; $f++)
 {

 Write-Host "*" -NoNewline

 }
  Write-Host 
 }