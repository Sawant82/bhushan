﻿while (Get-Process )

{


Get-Process | where {$_.Name -eq "notepad"} | kill

}
