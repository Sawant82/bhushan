﻿$NEWSTATE = Get-Process 

$OLDERSTATE = Import-Csv E:\Bhushan\PROCESS.CSV

FOREACH ($NEW in $NEWSTATE)
{


if ($OLDERSTATE | where {$_.name -eq $new.Name} )

{

write-host "No worry"
}
else
{
$new.Name | Out-File E:\Bhushan\newprocess.txt -Append
}
}