﻿ $b=@(0,1,2,3,4)

    for($c=0;$c -eq 3; $c++)
   {

   Write-Host "*"
   
    }  