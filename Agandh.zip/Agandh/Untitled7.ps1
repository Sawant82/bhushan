﻿ for ($e=0;$e -le 4; $e++)

 {

  for ($f=0;$f -lt $e; $f++)
 {

 Write-Host "*" -NoNewline
 
 }
  Write-Host 
 }






  for ($e=3;$e -ge 1; $e--)

 {
 
 for ($f=0;$f -lt $e; $f++)
 {

 Write-Host "%" -NoNewline

 }
  Write-Host 
 }