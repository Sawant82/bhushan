﻿ for ($e=1;$e -le 10; $e++)


 {

 New-Item -ItemType file -Path E:\Bhushan\$e.txt
 
 
 }
 






