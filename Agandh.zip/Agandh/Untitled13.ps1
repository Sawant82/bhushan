﻿$files = Get-ChildItem C:\Windows\System32\*.dll
$comparedate=(get-date).AddYears(-3)


foreach($file in $files) 

{


if($file.creationtime -le $comparedate)

{

$olderfiles = Write-Host $file.name "is olderthan 2015" -ForegroundColor red 



}

else
{

$newfiles = Write-Host $file.Name "is not older than 2015" -ForegroundColor DarkGreen  



}
$olderfiles | Out-File E:\Bhushan
}