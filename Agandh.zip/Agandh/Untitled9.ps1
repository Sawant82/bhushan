﻿$files = Get-ChildItem E:\Bhushan\ 
foreach($file in $files)
{

Write-Host $file
$file.Delete() 
#$file | Remove-Item

}