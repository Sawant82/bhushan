﻿$data = Get-ChildItem C:\Windows\System32\*.dll


$files = Get-Content $dat

foreach($file in $files) 

{


Where {$_.creationtime -le "2015"}

{

Write-Host "$file is olderthan 2015"

}


{

Write-Host $file is not older than 2015

}
}