﻿while (Get-Process )

{


stop-process -Name notepad

}
